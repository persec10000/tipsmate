Hello <strong>{{ $name }}</strong>,
<p>Your password is {{$body}}</p>
<p>For security, We recommend to reset administrator's password.</p>

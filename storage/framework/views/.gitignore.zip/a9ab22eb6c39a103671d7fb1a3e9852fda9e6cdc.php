<!DOCTYPE html>
<html lang="<?php echo e(app()->getLocale()); ?>">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title>TIPSMATE</title>
    <link href="https://fonts.googleapis.com/css?family=Raleway:100,600" rel="stylesheet" type="text/css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">

    <link rel="stylesheet" href="<?php echo e(asset('fireuikit/css/assets/font-awesome.min.css')); ?>">
    <link rel="icon" href="<?php echo e(asset('fireuikit/images/favicon.png')); ?>">
    <link href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700,900" rel="stylesheet">
    <?php echo $__env->yieldContent('link'); ?>
</head>

<body class="container-fluid">
    <header>
        <div class="row ml-3 hd">
            <div class="logo">
                <img src="<?php echo e(asset("fireuikit/images/Logo.png")); ?>">
            </div>
            <div class="toplist mt-2 ml-md-5">
                <div>
                    <img src="<?php echo e(asset("fireuikit/images/Picture1.png")); ?>">
                </div>
                <div>
                    <ul class="nav justify-content-center">
                        <li class="nav-item">
                            <a class="nav-link" href="#">ASK ME</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#">HOW TO</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#">Register</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#">Login</a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </header>

    <section>
        <div class="row">
            <div class="col-md-2 col-sm-2">
                <?php echo $__env->yieldContent('leftsidebar'); ?>
            </div>
            <div class="col-md-6 col-sm-6">
                <?php echo $__env->yieldContent('content'); ?>
            </div>
            <div class="col-md-2 col-sm-2">
                <?php echo $__env->yieldContent('rightside'); ?>
            </div>
        </div>
    </section>



</body>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.0/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
<?php echo $__env->yieldContent('js'); ?>
</html>
<?php /**PATH D:\Laravel\tipsmate\resources\views/layouts/basic.blade.php ENDPATH**/ ?>
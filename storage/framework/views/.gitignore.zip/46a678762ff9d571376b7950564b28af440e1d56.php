<?php $__env->startSection('link'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('fireuikit/css/assets/qa.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('fireuikit/css/assets/rightside.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('fireuikit/css/assets/jquery.rateyo.min.css')); ?>"/>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('leftside'); ?>
    <div class="row ml-lg-5">
        <img src="<?php echo e(asset('fireuikit/images/Picture2.png')); ?>" class="sidelogo ml-3">
    </div>
    <div id="cat-all" roll="navigation" class="row ml-lg-5">
        <ul class="none FW-400 MY-0 ml-3" id="categories">
            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li class="FC_list" data-product-id="cat<?php echo e($row->id); ?>" id="<?php echo e($row->id); ?>">
                    <?php echo e($row->category); ?>

                </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="col-md-6 col-sm-6">
        <div class="row">
            <form id="frm" name="frm" action="#">
                <div class="input-group">
                    <input type="text" class="form-control ml-3 mb-4" id="search" name="search">
                    <button id="answer_search" class="btn-search ml-3 mb-4 pl-3 pr-3" >Search Answers</button>
                </div>
                <div id="answer_list"></div>
            </form>
        </div>
        <div class="row">
            <button id="find" class="find ml-3 mr-3 mb-3">Find Questions</button>
            <button id="answer" class="answer ml-3 mr-3 mb-3">Answer Questions</button>
        </div>
        
        <div id='loader' style='display: none;'>
          <img src='<?php echo e(asset('fireuikit/images/ajax-loader.gif')); ?>' width='32px' height='32px'>
        </div>
        
        <div class="row">
            <ul id="fq" style="width: 100%">
                <?php $__currentLoopData = $questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li class="qa_content mb-1" style="width: 100%" id="li<?php echo e($question->data_id); ?>">
                        <div class="clearfix media p-3">
                            <img src="<?php echo e(asset('fireuikit/images/users/'.$question->ques_user_image)); ?>" width="50px" height="50px" style="float: left" class="mr-2 rounded-circle">
                            <div class="media-body">
                                <div class="ml-2">
                                    <div class="ques_content" id="<?php echo e($question->data_id); ?>">
                                        <h5>
                                            <a class="question" href="javascript:void(0)" id="<?php echo e($question->data_id); ?>"><?php echo e($question->title); ?></a>
                                        </h5>
                                        <div class="COM" id="com<?php echo e($question->data_id); ?>"><?php echo $question->comment; ?></div>
                                        <div id="edit_content<?php echo e($question->data_id); ?>" hidden><?php echo $question->all_comment; ?></div>

                                    </div>
                                    <div class="Wow-bw Lh-24"></div>
                                    <div class="row mt-2 config">
                                        <div class="col-3" style="text-align: left;font-size:14px">
                                            <p style="white-space: nowrap;width: 100%;overflow: hidden; text-overflow: ellipsis;">Category:&nbsp;&nbsp;<a href="javascript:void(0)" id="<?php echo e($question->id); ?>" class="category"><?php echo e($question->category); ?></a></p>
                                        </div>
                                        <div class="col-3" style="text-align: center;font-size:14px">
                                            Answers&nbsp;&nbsp;(<a href="javascript:void(0)"><?php echo e(count($question->answer)); ?></a>)
                                            <?php if(Auth::user()): ?>
                                                <?php if(Auth::user()->name==$question->name): ?>
                                                &nbsp;<a href="javascript:void(0)"><span class="editcomment" id="<?php echo e($question->data_id); ?>">Edit</span></a>
                                                &nbsp;<a href="javascript:void(0)"><span class="deletecomment" id="<?php echo e($question->data_id); ?>">Delete</span></a>
                                                <?php endif; ?>
                                            <?php endif; ?>
                                        </div>
                                        <div class="col-3" style="text-align: center;font-size:14px">
                                            <button class="ATQ" id="<?php echo e($question->data_id); ?>">Answer this Question</button>
                                        </div>
                                        <div class="col-3" style="text-align: left;font-size:14px">
                                            Posted by:&nbsp;&nbsp;<a href="javascript:void(0)"><?php if(strpos($question->name," ")!=""): ?><?php echo e(substr($question->name,0,strpos($question->name," "))); ?> <?php else: ?> <?php echo e($question->name); ?><?php endif; ?></a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <?php if(Auth::user()): ?>
                            <div class="item_answer ml-2 mr-2" id="item<?php echo e($question->data_id); ?>">
                                <form method="post" action="/answer" class="q_answer" id="form<?php echo e($question->data_id); ?>" enctype="multipart/form-data">
                                    <?php echo csrf_field(); ?>
                                    <input type="hidden" name="q_id" value="<?php echo e($question->data_id); ?>">
                                    <input type="hidden" name="user" value="<?php echo e(Auth::user()->name); ?>">
                                    <div class="form-group">
                                        <textarea id="summer<?php echo e($question->data_id); ?>" name="text" class="summernote form-control"></textarea>
                                    </div>
                                    <div class="form-group">
                                        <input type="submit" class="btn btn-primary" value="Submit"/>
                                        <input type="reset" class="btn btn_default summer_reset" id="<?php echo e($question->data_id); ?>" value="Reset"/>
                                    </div>
                                </form>
                            </div>
                            <div class="item_edit ml-2 mr-2" id="edit<?php echo e($question->data_id); ?>">
                                <form method="post" action="/editcomment" class="q_answer" id="form<?php echo e($question->data_id); ?>" enctype="multipart/form-data">
                                    <?php echo csrf_field(); ?>
                                    <input type="hidden" name="q_id" value="<?php echo e($question->data_id); ?>">
                                    <input type="hidden" name="user" value="<?php echo e(Auth::user()->name); ?>">
                                    <div class="form-group">
                                        <textarea id="editsummer<?php echo e($question->data_id); ?>" name="text" class="summernote form-control"></textarea>
                                    </div>
                                    <div class="form-group">
                                        <input type="submit" class="btn btn-primary" value="Submit"/>
                                        <input type="reset" class="btn btn_default edit_summer_reset" id="<?php echo e($question->data_id); ?>" value="Reset"/>
                                    </div>
                                </form>
                            </div>
                        <?php else: ?>
                            <div class="item_answer ml-5 mb-3" id="item<?php echo e($question->data_id); ?>">You have to sign in using your account to answer this question.</div>
                        <?php endif; ?>
                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php if(Auth::user()): ?>
<?php $__env->startSection('rightside'); ?>
    <div class=" col-md-2 col-sm-2">
        <div class="ml-5">
            <div id="askbar-holder">
                <form id="ask_frm" method="post" action="<?php echo e(route('addquestion')); ?>" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="Bgc-t Bgr-n Va-m Fl-start shared-sprite ask-star-icon D-ib Mend-5 Wpx-25 Hpx-25 Fl-start"
                        id="ask_sprite">
                        <img src="<?php echo e(asset('fireuikit/images/combo.png')); ?>">
                    </div>
                    <h2 class="D-ib Fz-18 Fw-300 Mt-neg-1" id="">Ask a Question</h2>
                    <div class="Fw-300" id="">
                        usually answered within minutes!
                    </div>
                    <div class="form-group mb-5">

                        <select class="mt-3 mb-3 form-control" id="sltitle" name="category">
                            <option selected>Select</option>
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($row->id != 1): ?>
                                <option value="<?php echo e($row->id); ?>"><?php echo e($row->category); ?></option>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>

                        <textarea class="form-control mb-3" name="title" placeholder="What's up" id="rtext"></textarea>
                        <div class="form-group">
                            <textarea id="summernote1" name="comment" class="form-control"></textarea>

                        </div>
                        <footer>
                            <ul>
                                <li>

                                    <input type="button" id="clear" class="btn btn_default" name="clear" value="Reset">
                                <li>
                                    <button id="send" type="submit" class="btn btn-primary">Send</button>
                                </li>
                            </ul>
                        </footer>
                    </div>
                </form>
            </div>
            <div class="google">
                <img src="<?php echo e(asset('fireuikit/images/google_ads.png')); ?>" style="width: 100%">
            </div>
            <div class="mt-3">
                <h4 style="font-weight: bold">Recent Posts......</h4>
                <p><?php echo e($questions[0]->title); ?></p>
                <p><?php echo e($questions[1]->title); ?></p>
                <p><?php echo e($questions[2]->title); ?></p>
                <p><?php echo e($questions[3]->title); ?></p>
                <p><?php echo e($questions[4]->title); ?></p>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php endif; ?>
<?php $__env->startSection('js'); ?>
   <script src="<?php echo e(asset('fireuikit/js/ask-content.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.basic', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home4/gordon2012/public_html/tipsmate/resources/views/home.blade.php ENDPATH**/ ?>
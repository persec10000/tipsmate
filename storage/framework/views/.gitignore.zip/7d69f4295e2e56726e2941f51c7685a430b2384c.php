<?php $__env->startSection('link'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('fireuikit/css/assets/qa.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('leftsidebar'); ?>
<div class="row">
    <img src="<?php echo e(asset('fireuikit/images/Picture2.png')); ?>" class="sidelogo ml-3">
</div>
<div id="cat-all" roll="navigation" class="row">
    <ul class="none FW-400 MY-0 ml-3">
        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li class="Mb-7 cat-link">
            <a href="" class="Mstart-3 unselected D-ib" id="<?php echo e($row['id']); ?>"><?php echo e($row['category']); ?></a>
        </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

        <div class="row">
            <form id="frm" name="frm" action="#">
                <div class="input-group">
                    <input type="text" class="form-control ml-3 mr-2 mb-4" id="search" name="search">
                    <button class="btn-search ml-3 mr-3 mb-4">Search Answers</button>
                </div>
            </form>
        </div>
        <div class="row">
            <button id="find" class="find ml-3 mr-3 mb-3">Find Questions</button>
            <button id="answer" class="answer ml-3 mr-3 mb-3">Answer Questions</button>
        </div>
        <div id="findquiz" class="row input-group">
            <input class="form-control ml-3" type="text" name="searchquiz">
            <div class="input-group-append">
                <button tabindex="-1" class="btn btn-primary" type="button">Search</button>
            </div>
        </div>
        <div class="row">
            <ul id="fq">
                <?php $__currentLoopData = $questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li>
                    <div class="row">
                        <h3><a class="" href="#" data-rapid_p="<?php echo e($question['id']); ?>"><?php echo e($question['title']); ?></a></h3>
                        <p>I have a new account for help/support and ranting to help people. I have like 85 followers and nobody sees my posts. How can I gain followers that aren't ghosts, people who will actually comment and be present.</p>
                    </div>
                    <div class="Wow-bw Lh-24"></div>
                    <div class="row">
                        <ul class="subdsc">
                            <li>Category:<a href="#">Social Science</a></li>
                            <li>Answers:<a href="">(8)</a></li>
                            <li>Posted by:<a href="">John</a></li>
                        </ul>
                    </div>
                </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('rightside'); ?>
    <div class="ml-5">
        <div id="askbar-holder">
            <form id="ask_frm" method="post" action="" >
                <div class="Bgc-t Bgr-n Va-m Fl-start shared-sprite ask-star-icon D-ib Mend-5 Wpx-25 Hpx-25 Fl-start" id="ask_sprite"><img src="<?php echo e(asset('fireuikit/images/combo.png')); ?>"></div>
                <h2 class="D-ib Fz-18 Fw-300 Mt-neg-1" id="">Ask a Question</h2>
                <div class="Fw-300" id="">
                    usually answered within minutes!
                </div>
                <div class="form-group mb-5">
                    <select class="mt-3 mb-3 form-control">
                        <option selected>Select</option>
                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <option value="<?php echo e($row['id']); ?>"><?php echo e($row['category']); ?></option>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>

                    <textarea class="form-control mb-3" name="title" placeholder="What's up" id=""></textarea>
                    <div class="custom-file">
                        <input type="file" class="" id="file" name="">
                        <button type="button" class="mr-3 btn btn-lg btn-primary" for="customfile"><i class="fa fa-photo"></i>Re</button>
                    </div>

                    <input type="submit" value="Submit" class="ml-3 btn btn-primary">

                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <script>
        $(document).ready(function () {

            $('#find').click(function () {
               $('#findquiz').fadeToggle();
            });
        })
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.basic', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Laravel\tipsmate\resources\views/home.blade.php ENDPATH**/ ?>